def gabung_dict(lista, listb):
    kamus = dict(zip(lista, listb))

    urutan_warna = ['green', 'blue', 'red']
    nomor_warna = {key: kamus[key] for key in urutan_warna}
    return nomor_warna

lista = ['red', 'green', 'blue']
listb = ['#FF0000', '#008000', '#0000FF']

dict = gabung_dict(lista, listb)
print(dict)
