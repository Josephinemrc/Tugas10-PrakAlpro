file_name = input("Masukkan nama file: ")
emails = dict()

with open(file_name, 'r') as file:
    for line in file:
        if line.startswith('Author'):
            kata = line.split()
            email = kata[1]
            pencarian = email.find('@')
            pengiriman = email[pencarian + 1:]
            emails[pengiriman] = emails.get(pengiriman, 0)+1
print(emails)
