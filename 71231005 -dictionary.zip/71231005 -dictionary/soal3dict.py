file_name = input("Masukkan nama file: ")
emails = dict()

with open(file_name, 'r') as file:
    for line in file:
        if line.startswith('From'):
            kata = line.split()
            email = kata[1]
            emails[email] = emails.get(email, 0) + 1
print(emails)
