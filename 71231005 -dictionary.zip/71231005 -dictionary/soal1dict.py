dictionary = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}

print("key".ljust(5), "value".ljust(7), "item")
for key, value in dictionary.items():
    print(str(key).ljust(5), str(value).ljust(7), str(key))
    